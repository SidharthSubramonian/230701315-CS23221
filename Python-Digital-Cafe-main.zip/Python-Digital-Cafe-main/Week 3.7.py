a=float(input())
if(a<100):
    print("100.00")
elif(a>=100 and a<199):
    print("%.2f"%(a*1.20))
elif((a>199 and a<400) and (a*1.50)>400):
    print("%.2f"%(a*1.50+((15/100)*(a*1.50))))
elif(a>400 and a<600):
    print("%.2f"%(a*1.80+((15/100)*(a*1.80))))
else:
    print("%.2f"%(a*2.00+((15/100)*(a*2.00))))
