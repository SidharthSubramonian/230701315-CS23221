num=input()
unidig=set()
for digit in num:
  unidig.add(digit)
unidigitcount=len(unidig)
print(unidigcount)
