t = input().split(',')
k = int(input())

s = []
s1=[]

for i in range(len(t)-1):
    for j in range(i+1,len(t)):
        if (int(t[i])+int(t[j]))==k and (t[i],t[j]) not in s1 and (t[i],t[j]) not in s1:
            s1.append((t[i],t[j]))
            s1.append((t[j],t[i]))
            s.append((t[i],t[j]))
            
print(len(set(s)))
