arr = list(map(int, input().split()))
frequency_dict = {}
for num in arr:
    if num in frequency_dict:
        frequency_dict[num] += 1
    else:
        frequency_dict[num] = 1
sorted_frequency = sorted(frequency_dict.items())
for key, value in sorted_frequency:
    print(key, value)
