x=int(input())
a=int(input())
b=int(input())
c=int(input())
d=int(input())
if(a%x==0):
    print("True",end=" ")
else:
    print("False",end=" ")
if(b%x==0):
    print("True",end=" ")
else:
    print("False",end=" ")
if(c%x==0):
    print("True",end=" ")
else:
    print("False",end=" ")
if(d%x==0):
    print("True",end=" ")
else:
    print("False",end=" ")
