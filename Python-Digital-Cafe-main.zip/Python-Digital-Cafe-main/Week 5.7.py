def expand_string(s):
    result = ""
    i = 0
    while i < len(s):
        char = s[i]
        i += 1
        num = ""
        while i < len(s) and s[i].isdigit():
            num += s[i]
            i += 1
        result += char * int(num)
    return result

s = input()
print(expand_string(s))
