a=float(input())
b= a**0.5
print("%.3f"%(b))
