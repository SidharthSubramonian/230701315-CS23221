a=int(input())
if(a%12==8):
    print(a,"is the year of the Dragon.")
elif(a%12==9):
    print(a,"is the year of the Snake.")
elif(a%12==10):
    print(a,"is the year of the Horse.")
elif(a%12==11):
    print(a,"is the year of the Sheep.")
elif(a%12==0):
    print(a,"is the year of the Monkey.")
elif(a%12==1):
    print(a,"is the year of the Rooster.")
elif(a%12==2):
    print(a,"is the year of the Dog.")
elif(a%12==3):
    print(a,"is the year of the Pig.")    
elif(a%12==4):
    print(a,"is the year of the Rat.")
elif(a%12==5):
    print(a,"is the year of the Ox.")
elif(a%12==6):
    print(a,"is the year of the Tiger.")
else:
    print(a,"is the year of the Hare.")
