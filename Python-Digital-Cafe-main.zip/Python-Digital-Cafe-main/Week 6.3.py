n1 = int(input())
array1 = [int(input()) for _ in range(n1)]
n2 = int(input())
array2 = [int(input()) for _ in range(n2)]
merged_array = list(set(array1 + array2))
merged_array.sort()
print(*merged_array)
