x=int(input())
y=int(input())
a=x*75
b=y*112
print(f"The total weight of all these widgets and gizmos is {a+b} grams.")
