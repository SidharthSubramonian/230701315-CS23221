x=int(input())
y=(4/100)*x
z=x+y
a=(4/100)*z
b=a+z
c=(4/100)*b
d=b+c
print("Balance as of end of Year 1:","$%.2f."%z)
print("Balance as of end of Year 2:","$%.2f."%b)
print("Balance as of end of Year 3:","$%.2f."%d)
