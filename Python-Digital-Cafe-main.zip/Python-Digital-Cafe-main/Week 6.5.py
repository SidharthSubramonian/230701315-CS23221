n = int(input())
arr = [int(input())for _ in range(n)]
frequency = {}
for num in arr:
    if num in frequency:
        frequency[num] += 1
    else:
        frequency[num] = 1
for num, freq in frequency.items():
    print(f"{num} occurs {freq} times")
