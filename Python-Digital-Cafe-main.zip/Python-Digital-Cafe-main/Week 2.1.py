x=int(input())
if(x==0):
    print("C")
else:
    print("D")
    
