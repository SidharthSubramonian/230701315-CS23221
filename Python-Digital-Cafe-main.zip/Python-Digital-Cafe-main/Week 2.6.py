x=int (input())
a=(5/100)*x
b=(18/100)*x
y=x+a+b
print("The tax is","%.2f"%a,"and the tip is","%.2f,"%b,"making the total","%.2f"%y)
