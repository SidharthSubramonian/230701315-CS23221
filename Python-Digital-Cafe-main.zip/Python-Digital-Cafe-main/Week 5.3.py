s1=input()
s=[i for i in s1]
t1=0
t2=len(s)-1
for i in range(len(s)//2):
    if s[t1].isalpha()==s[t2].isalpha():
        s[t1],s[t2]=s[t2],s[t1]
        t1+=1
        t2-=1
        continue
    elif(s[t1].isalpha()):
        t2-=1
    elif(s[t2].isalpha()):
        t1+=1
    else:
        t1+=1
        t2-=1
print(''.join(s))
