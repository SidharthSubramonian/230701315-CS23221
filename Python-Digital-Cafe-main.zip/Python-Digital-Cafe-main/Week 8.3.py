n= int(input())
votes_count = {}
for _ in range(n):
    candidate = input().strip()
    votes_count[candidate] = votes_count.get(candidate, 0) + 1
max_votes = max(votes_count.values())
winners = [candidate for candidate, votes in votes_count.items() if votes == max_votes]
print(sorted(winners)[0])
