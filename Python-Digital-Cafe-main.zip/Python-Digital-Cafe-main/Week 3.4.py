x=int(input())
y=str(x)
if(len(y)==1):
    print("-1")
else:
    print(y[-2])
    
