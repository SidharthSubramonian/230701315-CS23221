n=int(input())
if n<10:
  print("Yes")
else:
  for factor in range(2,10):
    if(n%factor==0 and 1<=n//factor<=9):
      print("Yes")
      break
    else:
      print("No")
