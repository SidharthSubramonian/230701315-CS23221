n=int(input())
for j in range(n):
    sum1,sum2=0,0
    s1=input().upper()
    s2=input().upper()
    sum1=sum(ord(i) for i in s1)
    sum2=sum(ord(i) for i in s2)
    if s1==s2:
        print(0)
    elif(sum1>sum2):
        print(1)
    else:
        print(-1)
