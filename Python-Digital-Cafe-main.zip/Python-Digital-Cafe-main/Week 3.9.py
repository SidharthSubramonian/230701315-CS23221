a=int(input())
b=int(input())
c=int(input())
if((a>=65 and b>=55 and c>=50)or(a+b+c)>=180):
    print("The candidate is eligible")
else:
    print("The candidate is not eligible")
