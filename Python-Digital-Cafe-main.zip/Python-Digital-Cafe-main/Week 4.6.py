n=int(input())
if(n<1):
  for i in range(2,n):
    if(n%i)==0:
      print("1")
      break
    else:
      print("2")
else:
  print("1")
