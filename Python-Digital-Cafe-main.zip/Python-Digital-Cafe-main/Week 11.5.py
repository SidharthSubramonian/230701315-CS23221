import math

def calculate_square_root():
    try:
        num = float(input())
        if num < 0:
            print("Error: Cannot calculate the square root of a negative number.")
        else:
            sqrt = math.sqrt(num)
            print(f"The square root of {num} is {sqrt:.2f}")
    except ValueError:
        print("Error: could not convert string to float")

calculate_square_root()
