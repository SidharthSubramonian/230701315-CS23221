num=int(input())
while 1:
  num=num+1
  root=(num**0.5)
  if(root==int(root):
    print(num)
    break
