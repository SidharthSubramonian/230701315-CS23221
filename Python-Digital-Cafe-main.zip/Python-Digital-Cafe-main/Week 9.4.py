def automorphic(n):
    sq = n ** 2
    ld = sq % (10 ** len(str(n)))
    if n == ld:
        return "Automorphic"
    else:
        return "Not Automorphic"
