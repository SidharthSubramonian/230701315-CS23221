x=int(input())
y=int(input())
if(x>=18 and y>40):
    print("True")
else:
    print("False")
