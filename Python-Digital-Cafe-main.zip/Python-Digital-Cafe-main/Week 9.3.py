def productDigits(number):
    number_str = str(number)
    product_even_positions = 1
    sum_odd_positions = 0
    
    for i, digit in enumerate(number_str, start=1):
        digit = int(digit)
        if i % 2 == 1:
            sum_odd_positions += digit
        else:
            product_even_positions *= digit

    if sum_odd_positions == 0:
        return False

    return product_even_positions % sum_odd_positions == 0
