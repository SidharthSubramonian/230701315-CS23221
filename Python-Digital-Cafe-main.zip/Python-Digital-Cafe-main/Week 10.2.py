def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        # Flag to check if any swapping is done in this pass
        swapped = False
        for j in range(0, n-i-1):
            # Swap if the element found is greater than the next element
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                swapped = True
        # If no swapping is done in this pass, the array is already sorted
        if not swapped:
            break
    return arr

if __name__ == "__main__":
    # Input the number of elements
    n = int(input())
    
    # Input the array elements
    arr = list(map(int, input().split()))

    # Sort the array using bubble sort
    sorted_arr = bubble_sort(arr)
    
    # Print the sorted array
    print(*sorted_arr,sep = " ")
