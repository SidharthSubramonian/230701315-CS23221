try:
    age = int(input(""))
    if age < 0:
        print("Error: Please enter a valid age.")
    else:
        print(f"You are {age} years old.")
except ValueError:
    print("Error: Please enter a valid age.")
except EOFError:
    print("Error: Please enter a valid age.")
