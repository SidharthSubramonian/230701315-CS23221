a=int(input())
b=int(input())
c=int(input())
if(a==b and a==c):
    print("That's a equilateral triangle")
elif(a==b and a!=c):
    print("That's a isosceles triangle")
else:
    print("That's a scalene triangle")
