def count_unique_pairs(n,activities,k):
    unique_pairs=set()
    for i in range(n):
        for j in range(i+1,n):
            if abs(activities[i]-activities[j])==k:
                unique_pairs.add((i,j))
    return len(unique_pairs)
def main():
    n=int(input())
    activities=list(map(int,input().split()))
    k=int(input())
    result=count_unique_pairs(n,activities,k)
    print(result)
main()
