X = int(input())
shoes = list(map(int, input().split()))
inventory = {}
for shoe in shoes:
    if shoe in inventory:
        inventory[shoe] += 1
    else:
        inventory[shoe] = 1
N = int(input())
total_revenue = 0
for _ in range(N):
    size, price = map(int, input().split())
    if size in inventory and inventory[size] > 0:
                inventory[size] -= 1
                total_revenue += price
print(total_revenue)
