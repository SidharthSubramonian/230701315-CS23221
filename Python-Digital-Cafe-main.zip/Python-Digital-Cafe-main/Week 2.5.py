x= int(input())
if(x<100 and x>1):
    if(x%2==0):
        print("True")
else:
    print("False")
        
