a=int(input())
sum=0
for i in range(1,a+1):
  sum+=(10**i-1)/9
print("%d"%sum)  
