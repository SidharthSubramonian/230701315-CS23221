a=int(input())
b=float(input())
print(a,type(a),sep=',')
print(round(b,1),type(b),sep=',')
