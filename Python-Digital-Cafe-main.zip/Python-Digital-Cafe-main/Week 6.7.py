a=int(input())

for  i in range(a):
    l=[]
    b=int(input())
    t=1
    for j in range(b):
        l.append(int(input()))
    
    c=int(input())
    for m in range(len(l)-1):
        
        for s in range(m+1,len(l)):
        
            if (abs(l[m]-l[s])==c ):
                
                t=0
            
                break
        
    if(t==1):
        print("0")
    else:
        print("1")
