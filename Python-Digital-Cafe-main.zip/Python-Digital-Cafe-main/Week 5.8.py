s= input().lower().split()
for i in s:
    if i!=i[::-1]:
        print(i,end=' ')
