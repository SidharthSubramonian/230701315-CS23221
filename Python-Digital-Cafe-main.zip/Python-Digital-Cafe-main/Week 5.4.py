x=input()
a,b,c=0,0,0
for i in x:
    if(i.isalpha()):
        a+=1
    elif(i.isalnum()):
        b+=1
    else:
        c+=1
print(a,b,c,sep="\n")        
