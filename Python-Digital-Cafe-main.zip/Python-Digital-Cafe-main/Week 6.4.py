x=[]
for i in range(0,11):
    b=int(input())
    x.append(b)
print("ITEM to be inserted:",x[-1],sep='')
x.sort()
print("After insertion array is:")
for i in x:
    print(i)
