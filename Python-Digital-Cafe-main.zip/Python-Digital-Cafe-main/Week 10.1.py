def bubble_sort(arr):
    n=len(arr)
    swaps=0
    for i in range(n):
        for j in range(n-1):
            if arr[j]>arr[j+1]:
                arr[j],arr[j+1]=arr[j+1],arr[j]
                swaps+=1
    return swaps
n=int(input())
arr=list(map(int,input().split()))
num_swaps=bubble_sort(arr)
print("List is sorted in",num_swaps, "swaps.")
print("First Element:",arr[0])
print("Last Element:",arr[-1])
