n = int(input())
test_dict = {}
for _ in range(n):
    key, *values = input().split()
    values = list(map(int, values))
    test_dict[key] = sum(values)
sorted_dict = dict(sorted(test_dict.items(), key=lambda item: item[1]))
for key, value in sorted_dict.items():
    print(key, value)
