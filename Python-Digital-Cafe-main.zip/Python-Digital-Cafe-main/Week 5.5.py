a=input()
b=input()
for i in a:
    if(i not in b):
        print(i,end="")
    
