x=input()
y=input()
print(x.index(y))
