def safe_division():
    try:
        num1 = float(input())
        num2 = float(input( ))

        if num2 == 0:
            raise ZeroDivisionError

        result = num1 / num2
        print(result)

    except ValueError:
        print("Error: Non-numeric input provided.")
    except ZeroDivisionError:
        print("Error: Cannot divide or modulo by zero.")
    except Exception as e:
        print("An unexpected error occurred:", str(e))

safe_division()
