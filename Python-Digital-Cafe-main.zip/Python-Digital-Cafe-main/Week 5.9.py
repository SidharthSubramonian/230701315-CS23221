l=[]
ch=input()
while(ch!=' '):
    if ch not in l:
        l.append(ch)
    ch=input()
for i in l:
    print(i)
