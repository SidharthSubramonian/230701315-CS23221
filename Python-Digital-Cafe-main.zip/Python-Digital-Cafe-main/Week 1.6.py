n=int(input())
x=abs(n-500)/130
print("weekdays",format(x+10,".2f"))
print("weekend",format(x,".2f"))
