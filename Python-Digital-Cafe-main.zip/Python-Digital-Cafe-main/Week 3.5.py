a=int(input())
b=int(input())
c=a/2
if(b>=c):
    print("IN")
else:
    print("OUT")
