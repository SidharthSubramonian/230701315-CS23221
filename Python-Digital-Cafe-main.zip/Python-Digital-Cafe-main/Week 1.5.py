a = int(input())
b = int(input())
c = a*0.1
d = b*0.25
total = "%.2f"%(c+d)
print(f"Your total refund will be ${total}.")
