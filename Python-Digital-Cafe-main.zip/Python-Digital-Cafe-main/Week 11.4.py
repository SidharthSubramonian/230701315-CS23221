try:
    a=int(input())
    if (a >= 1 and a <= 100 ) :
        print("Valid input.")
    elif (a > 100 ) :

        print("Error: Number out of allowed range")

    elif (a <= 0):
        print("Error: Number out of allowed range")

except: 
    print("Error: invalid literal for int()")
