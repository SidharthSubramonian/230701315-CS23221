def uncommon_words(s1, s2):
    def count_words(sentence):
        word_count = {}
        for word in sentence.split():
            word_count[word] = word_count.get(word, 0) + 1
        return word_count
    s1_words = count_words(s1)
    s2_words = count_words(s2)
    uncommon_words = []
    for word, count in s1_words.items():
        if count == 1 and word not in s2_words:
            uncommon_words.append(word)
    for word, count in s2_words.items():
        if count == 1 and word not in s1_words:
            uncommon_words.append(word)
    return uncommon_words
s1 =input()
s2=input()
print(*uncommon_words(s1, s2)) 
