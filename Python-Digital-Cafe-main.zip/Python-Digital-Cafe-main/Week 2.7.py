x=abs(int(input()))
a=(x%10)
print(a)
