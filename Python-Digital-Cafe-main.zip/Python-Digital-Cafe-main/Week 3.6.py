a=int(input())
if(a%400==0 and a%100==0 and a%4==0):
    print(a,"is a leap year.")
else:
    print(a,"is not a leap year.")
