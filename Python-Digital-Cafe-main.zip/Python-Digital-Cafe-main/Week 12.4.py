def is_power_of_two(n):
    return n > 0 and (n & (n - 1)) == 0
def main():
    n = int(input())
    print(is_power_of_two(n))
main()
