X = int(input())
Y = int(input())
Z = int(input())
a=X+Y
a = ((Z-a)/a)*100
print("%.2f"%(a),"is the gain percent.")
