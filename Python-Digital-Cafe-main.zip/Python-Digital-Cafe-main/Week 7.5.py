a = input()
try:
    c = int(a)
    print("Yes")
except:
    print("No")
