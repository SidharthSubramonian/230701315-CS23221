a=input()
if(a=='January' or a=='March' or a=='May' or a=='July' or a=='August' or a=='October' or a=='December'):
    print(a,"has 31 days in it.")
elif(a=='February'):
    print(a,"has 28 or 29 days in it.")
else:
    print(a,"has 30 days in it.")
