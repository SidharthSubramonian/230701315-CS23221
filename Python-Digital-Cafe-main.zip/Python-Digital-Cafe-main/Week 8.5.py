d = {1:"A, E, I, L, N, O, R, S, T, U",2:"DG",3:"BCMP", 4:" F, H, V, W, Y", 5:"K", 8:"JX", 10:"QZ"}
a=input()
c=0
for i in d:
    for j in a:
        if j in d[i]:
            c+=i
print(a,"is worth",c,"points.")            
