def calculate_average_marks(N, columns, student_data):
    total_marks = 0
    num_students = 0

    # Find the index of the 'MARKS' column
    marks_index = columns.index('MARKS')

    # Iterate through the student data to calculate total marks
    for student in student_data:
        # Extract marks for the current student
        marks = int(student[marks_index])
        total_marks += marks
        num_students += 1

    # Calculate the average marks
    average_marks = total_marks / num_students if num_students > 0 else 0

    return average_marks


N = int(input())
columns = input().split()
student_data = [input().split() for _ in range(N)]


average_marks = calculate_average_marks(N, columns, student_data)


print("{:.2f}".format(average_marks))
