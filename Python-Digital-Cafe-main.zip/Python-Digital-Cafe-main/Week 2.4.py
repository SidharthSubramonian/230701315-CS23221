x=int(input())
y=str(bin(x))
z=y.count('1')
print(z) 
