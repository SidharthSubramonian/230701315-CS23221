n = int(input())
students = {}
for _ in range(n):
    name, tm, am, lm = input().split()
    tm, am, lm = map(int, (tm, am, lm))
    students[name] = (tm, am, lm)
avg_scores = {name: sum(scores) / 3 for name, scores in students.items()}
highest_avg = max(avg_scores.values())
students_highest_avg = [name for name, avg in avg_scores.items() if avg == highest_avg]
highest_assignment = max(student[1] for student in students.values())
students_highest_assignment = [name for name, marks in students.items() if marks[1] == highest_assignment]
lowest_lab = min(student[2] for student in students.values())
students_lowest_lab = [name for name, marks in students.items() if marks[2] == lowest_lab]
lowest_avg = min(avg_scores.values())
students_lowest_avg = [name for name, avg in avg_scores.items() if avg == lowest_avg]
print(' '.join(sorted(students_highest_avg)))
print(' '.join(sorted(students_highest_assignment)))
print(' '.join(sorted(students_lowest_lab)))
print(' '.join(sorted(students_lowest_avg)))
