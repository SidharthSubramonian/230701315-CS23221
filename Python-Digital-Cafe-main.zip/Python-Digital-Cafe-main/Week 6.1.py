n = int(input())
A = list(map(int, input().split()))
B = list(map(int, input().split()))
P = []
indices= {num: i for i, num in enumerate(B)}
for num in A:
    P.append(indices[num])
print(*P)
