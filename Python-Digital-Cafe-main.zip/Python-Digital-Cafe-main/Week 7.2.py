def can_type(text, brokenLetters):

    words = text.split()

    valid_word_count = 0

 
    for word in words:
       
        valid = True
       
        for letter in word:
            letter=letter.lower()
            if letter in brokenLetters:
                valid = False
                break
        if valid:
            valid_word_count += 1

    return valid_word_count


text = input()
brokenLetters = input()
print(can_type(text, brokenLetters)) 
