x=int(input())
y=int(input())
z=(x%3==0)
a=(y%2==0)
if(a and z):
    print("True")
else:
    print("False")
