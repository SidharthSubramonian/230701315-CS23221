x=input().split()
ans=max(x,key=len)
print(ans)
print(len(ans))
