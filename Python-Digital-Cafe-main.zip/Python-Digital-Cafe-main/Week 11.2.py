try:
    num1 = float(input(""))
    num2 = float(input(""))
    division_result = num1 / num2
    modulo_result = num1 % num2
    print(f"Division result: {division_result:}")
    print(f"Modulo result: {modulo_result:.0f}")
except ZeroDivisionError:
    print("Error: Cannot divide or modulo by zero.")
except ValueError:
    print("Error: Non-numeric input provided.")
