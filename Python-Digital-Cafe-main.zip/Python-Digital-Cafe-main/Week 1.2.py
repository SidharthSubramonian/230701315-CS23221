a = int (input())
b = (40*a)/100
c = (20*a)/100
print (int(a+b+c))
