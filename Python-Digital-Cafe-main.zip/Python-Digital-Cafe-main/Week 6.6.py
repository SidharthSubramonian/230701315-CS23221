n=int(input())
x=[]
for _ in range(n):
    x.append(int(input()))

y = set(x)
print(*y)
